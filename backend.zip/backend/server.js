const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();

// Replace with your MongoDB Atlas URL or local MongoDB URL
mongoose.connect('mongodb+srv://jaibalaji28112003:cW3yhVmNbnxcVOOF@cluster0.dwk7x.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const studentSchema = new mongoose.Schema({
    name: String,
    dob: Date,
    branch: String,
    rollNo: String
});

const Student = mongoose.model('Student', studentSchema);

app.use(cors()); // Use CORS middleware
app.use(express.json()); // Parse JSON bodies

// API to add a student
app.post('/api/students', async (req, res) => {
    const { name, dob, branch, rollNo } = req.body;
    try {
        const student = new Student({ name, dob, branch, rollNo });
        await student.save();
        res.status(201).send(student);
    } catch (err) {
        res.status(400).send(err);
    }
});

// API to delete a student by roll number
app.delete('/api/students/:rollNo', async (req, res) => {
    const { rollNo } = req.params;
    try {
        await Student.deleteOne({ rollNo });
        res.status(200).send({ message: 'Student deleted successfully' });
    } catch (err) {
        res.status(400).send(err);
    }
});

// API to update student details by roll number
app.put('/api/students/:rollNo', async (req, res) => {
    const { rollNo } = req.params;
    const { name, dob, branch } = req.body;
    try {
        const student = await Student.findOneAndUpdate({ rollNo }, { name, dob, branch }, { new: true });
        res.status(200).send(student);
    } catch (err) {
        res.status(400).send(err);
    }  
});

// API to fetch students with optional filters
app.get('/api/students', async (req, res) => {
    const { branch, rollNo, dob } = req.query;
    try {
        const query = {};
        if (branch) query.branch = branch;
        if (rollNo) query.rollNo = rollNo;
        if (dob) query.dob = new Date(dob);

        const students = await Student.find(query);
        res.status(200).send(students);
    } catch (err) {
        res.status(400).send(err);
    }
});

// Start the server
app.listen(5000, () => console.log('Server is running on port 5000'));
